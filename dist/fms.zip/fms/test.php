<?php

	echo "Username Is taken";
	echo "<br>";
	echo "<a href='register.php'>Go Back To Registration</a>";




?>